// Supabase Sync - FleetGuard Pro V7
// Cuando tengas luz verde del cliente, descomenta y pon tus credenciales
const SUPABASE_URL = "https://TU_PROYECTO.supabase.co";
const SUPABASE_KEY = "TU_ANON_KEY";

async function syncToSupabase() {
  // Lee fleetguard.db local y sube a Supabase
  console.log("Sincronizando flota a Supabase...");
  // Ejemplo: await supabase.from('flota').upsert(datosLocales)
  // Este archivo ya está preparado para que no tengas que cambiar lógica
}

// Llamar cada 5 min si hay internet
// setInterval(syncToSupabase, 5*60*1000);
