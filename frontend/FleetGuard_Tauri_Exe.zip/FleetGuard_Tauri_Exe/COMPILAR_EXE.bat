@echo off
echo === FleetGuard Pro V7 - Compilador .EXE ===
echo.
echo Verificando Rust...
rustc --version
if %errorlevel% neq 0 (
  echo Instala Rust desde https://www.rust-lang.org/tools/install
  pause
  exit /b
)
echo.
echo Compilando .EXE portable (tarda 3-5 min primera vez)...
npm run tauri build
echo.
echo Listo! Tu .EXE esta en src-tauri/target/release/bundle/
echo.
pause
