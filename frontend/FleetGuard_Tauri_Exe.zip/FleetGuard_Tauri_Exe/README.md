# FleetGuard Pro V7 - Proyecto .EXE Portable Tauri

## Qué tienes aquí
Este es el Paso 3 completo. De HTML+DB a .EXE real de 15MB sin instalación.

Contenido:
- fleetguard.db -> BD SQLite real (20 demo, escalable a 200, con 14 alertas)
- src/index.html -> Dashboard V7 definitivo (tu diseño #07080A, lime #C6FF00, verde #00FFA3)
- src-tauri/ -> Proyecto Rust+Tauri para compilar .exe
- src/sync_supabase.js -> Preparado para sync web

## Cómo compilar el .EXE en tu PC (Windows)

Requisitos una sola vez:
1. Instala Rust: https://www.rust-lang.org/tools/install (click "Install" - 2 min)
2. Instala Node.js: https://nodejs.org/ (LTS)
3. En CMD: npm install -g @tauri/cli

Compilar:
1. Abre esta carpeta en terminal (CMD o PowerShell)
2. npm create tauri-app (si no tienes el proyecto, pero ya lo tienes)
3. npm run tauri build

Resultado:
- src-tauri/target/release/bundle/msi/FleetGuard Pro_7.0.0_x64_en-US.msi (instalador)
- src-tauri/target/release/bundle/exe/FleetGuard Pro_7.0.0_x64.exe (portable .exe único de ~15MB)

## Modo Portable sin instalar (lo que quieres para demo cliente)

En tauri.conf.json ya está:
"resources": ["fleetguard.db"]

Eso hace que el .exe lleve la BD dentro y no necesite instalar nada.
El cliente hace doble click y corre:
- Lee fleetguard.db embebida
- Muestra dashboard V7
- Guarda cambios en %APPDATA%/fleetguard.db
- Si hay internet, sincroniza a Supabase (cuando pongas credenciales en sync_supabase.js)

## Cómo funciona con tus filtros

En main.rs ya tienes comandos:
- get_flota() -> devuelve flota para filtros En Ruta/En Base/En Taller + GPS
- get_rutas_sospechosas() -> para filtros combustible Bajo/Normal/Excedido/Sospechoso
- get_mantenimiento_proximo() -> para filtros Aun no/Proximos 1000/Ciclo Preventivo

En index.html ya los puedes llamar con:
await invoke('get_flota')

## Próximo paso a web (Supabase)

1. Crea proyecto gratis en supabase.com
2. Importa fleetguard_schema_real.sql (que ya tienes)
3. Pon URL y KEY en src/sync_supabase.js
4. Descomenta setInterval

Con eso, lo que captures en el .exe se sube automático a la web mjd-solutions.mx

## Soporte
MJD Solutions - Davo Covarrubias
Paleta V2: #07080A fondo, #C6FF00 lime, #00FFA3 verde neón
