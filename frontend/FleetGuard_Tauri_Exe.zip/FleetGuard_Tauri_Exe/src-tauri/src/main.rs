#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]
use rusqlite::{Connection, Result};
use tauri::api::path::resource_dir;

fn main() {
  tauri::Builder::default()
    .invoke_handler(tauri::generate_handler![get_flota, get_rutas_sospechosas, get_mantenimiento_proximo])
    .run(tauri::generate_context!())
    .expect("error while running tauri application");
}

#[tauri::command]
fn get_flota() -> String {
  let conn = Connection::open("fleetguard.db").unwrap();
  let mut stmt = conn.prepare("SELECT placa, marca, modelo, estado, odometro_actual, ultima_lat, ultima_lng FROM flota LIMIT 200").unwrap();
  let rows = stmt.query_map([], |row| {
    Ok(format!("{}|{}|{}|{}|{}|{}|{}", row.get::<_, String>(0)?, row.get::<_, String>(1)?, row.get::<_, String>(2)?, row.get::<_, String>(3)?, row.get::<_, i32>(4)?, row.get::<_, f64>(5)?, row.get::<_, f64>(6)?))
  }).unwrap();
  let mut out = Vec::new();
  for r in rows { out.push(r.unwrap()); }
  out.join("\n")
}

#[tauri::command]
fn get_rutas_sospechosas() -> String {
  let conn = Connection::open("fleetguard.db").unwrap();
  let mut stmt = conn.prepare("SELECT placa, estado_consumo, COUNT(*) FROM rutas WHERE estado_consumo IN ('CRITICO','SOSPECHOSO') GROUP BY placa, estado_consumo").unwrap();
  let rows = stmt.query_map([], |row| {
    Ok(format!("{}: {} ({})", row.get::<_, String>(0)?, row.get::<_, String>(1)?, row.get::<_, i32>(2)?))
  }).unwrap();
  let mut out = Vec::new();
  for r in rows { out.push(r.unwrap()); }
  out.join("\n")
}

#[tauri::command]
fn get_mantenimiento_proximo() -> String {
  let conn = Connection::open("fleetguard.db").unwrap();
  let mut stmt = conn.prepare("SELECT placa, falta_km, estado FROM mantenimiento ORDER BY falta_km ASC LIMIT 50").unwrap();
  let rows = stmt.query_map([], |row| {
    Ok(format!("{} - faltan {} km - {}", row.get::<_, String>(0)?, row.get::<_, i32>(1)?, row.get::<_, String>(2)?))
  }).unwrap();
  let mut out = Vec::new();
  for r in rows { out.push(r.unwrap()); }
  out.join("\n")
}
