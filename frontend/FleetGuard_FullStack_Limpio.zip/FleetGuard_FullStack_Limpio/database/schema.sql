-- FleetGuard Pro V7 - Schema Escalable con Sucursales (futuro)
-- PostgreSQL / Supabase y SQLite compatible

-- 1. SUCURSALES (nueva, para futuro)
CREATE TABLE IF NOT EXISTS sucursales (
  id SERIAL PRIMARY KEY,
  nombre TEXT NOT NULL,
  clave TEXT UNIQUE, -- SUC-CDMX-01
  direccion TEXT,
  ciudad TEXT,
  estado_mx TEXT,
  telefono TEXT,
  responsable TEXT,
  activa BOOLEAN DEFAULT true,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 2. FLOTA
CREATE TABLE IF NOT EXISTS flota (
  id SERIAL PRIMARY KEY,
  placa TEXT UNIQUE NOT NULL,
  tipo TEXT NOT NULL, -- Camión, Auto, Autobus
  marca TEXT, modelo TEXT,
  nro_serie TEXT UNIQUE,
  color TEXT, anio INTEGER,
  carga_max_kg INTEGER,
  estado TEXT DEFAULT 'Disponible' CHECK(estado IN ('Disponible','En Ruta','En Base','En Taller','Mantenimiento')),
  -- Mantenimiento
  ciclo_mantenimiento_km INTEGER DEFAULT 5000,
  odometro_actual INTEGER DEFAULT 0,
  odometro_ultimo_mantenimiento INTEGER DEFAULT 0,
  -- GPS Telcel
  gps_id TEXT,
  gps_activo BOOLEAN DEFAULT true,
  ultima_lat DECIMAL(10,8),
  ultima_lng DECIMAL(11,8),
  -- Relación con sucursal (futuro)
  sucursal_id INTEGER REFERENCES sucursales(id) ON DELETE SET NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 3. CONDUCTORES
CREATE TABLE IF NOT EXISTS conductores (
  id SERIAL PRIMARY KEY,
  doc_identidad TEXT UNIQUE,
  nombre TEXT NOT NULL,
  nro_licencia TEXT,
  telefono TEXT,
  calificacion INTEGER DEFAULT 5,
  indice_consumo DECIMAL(4,2) DEFAULT 1.00,
  indice_fallas INTEGER DEFAULT 0,
  sucursal_id INTEGER REFERENCES sucursales(id) ON DELETE SET NULL,
  estado TEXT DEFAULT 'Disponible',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 4. RUTAS
CREATE TABLE IF NOT EXISTS rutas (
  id SERIAL PRIMARY KEY,
  nro_viaje TEXT UNIQUE,
  fecha_salida TIMESTAMP,
  fecha_llegada TIMESTAMP,
  placa TEXT NOT NULL REFERENCES flota(placa),
  conductor_id INTEGER REFERENCES conductores(id),
  origen TEXT, destino TEXT,
  kms_inicial INTEGER, kms_final INTEGER,
  kms_recorridos INTEGER,
  -- Combustible CORE
  volumen_gal DECIMAL(8,3),
  rendimiento_km_gal DECIMAL(6,2),
  rendimiento_esperado DECIMAL(6,2),
  estado_consumo TEXT, -- CRITICO/SOSPECHOSO/EXCEDIDO/NORMAL/BAJO
  total_combustible DECIMAL(10,2),
  ingreso_total DECIMAL(10,2),
  estado_ruta TEXT DEFAULT 'Libre',
  sucursal_id INTEGER REFERENCES sucursales(id) ON DELETE SET NULL,
  ruta_gps_json TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 5. MANTENIMIENTO
CREATE TABLE IF NOT EXISTS mantenimiento (
  id SERIAL PRIMARY KEY,
  placa TEXT NOT NULL REFERENCES flota(placa),
  fecha_agendada DATE,
  tipo TEXT DEFAULT 'Preventivo',
  paquete TEXT,
  costo DECIMAL(10,2) DEFAULT 0,
  estado TEXT DEFAULT 'No Agendado' CHECK(estado IN ('No Agendado','Agendado','En Taller','Completado','Vencido')),
  falta_km INTEGER,
  sucursal_id INTEGER REFERENCES sucursales(id) ON DELETE SET NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 6. GPS TRACKING
CREATE TABLE IF NOT EXISTS gps_tracking (
  id SERIAL PRIMARY KEY,
  placa TEXT REFERENCES flota(placa),
  lat DECIMAL(10,8), lng DECIMAL(11,8),
  velocidad INTEGER,
  timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Índices para 200+ vehículos
CREATE INDEX IF NOT EXISTS idx_flota_estado ON flota(estado);
CREATE INDEX IF NOT EXISTS idx_flota_sucursal ON flota(sucursal_id);
CREATE INDEX IF NOT EXISTS idx_rutas_placa ON rutas(placa);
CREATE INDEX IF NOT EXISTS idx_rutas_estado_consumo ON rutas(estado_consumo);

-- Datos iniciales - Sucursales ejemplo
INSERT INTO sucursales (nombre, clave, ciudad, estado_mx) VALUES
('Matriz CDMX', 'SUC-CDMX-01', 'CDMX', 'Ciudad de México'),
('Sucursal Puebla', 'SUC-PUE-01', 'Puebla', 'Puebla'),
('Sucursal Querétaro', 'SUC-QRO-01', 'Querétaro', 'Querétaro')
ON CONFLICT (clave) DO NOTHING;
