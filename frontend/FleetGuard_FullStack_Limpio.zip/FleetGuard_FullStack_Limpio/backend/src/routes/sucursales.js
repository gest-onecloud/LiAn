const express = require('express');
const router = express.Router();

const sucursales = [
  { id: 1, nombre: "Matriz CDMX", clave: "SUC-CDMX-01", ciudad: "CDMX", activa: true, total_unidades: 85 },
  { id: 2, nombre: "Sucursal Puebla", clave: "SUC-PUE-01", ciudad: "Puebla", activa: true, total_unidades: 65 },
  { id: 3, nombre: "Sucursal Querétaro", clave: "SUC-QRO-01", ciudad: "Querétaro", activa: true, total_unidades: 50 }
];

router.get('/', (req, res) => res.json(sucursales));
router.get('/:clave/flota', (req, res) => {
  // Futuro: devolver flota filtrada por sucursal
  res.json({ sucursal: req.params.clave, mensaje: "Aquí irá flota por sucursal cuando crezca a 200+ unidades" });
});

module.exports = router;
