const express = require('express');
const router = express.Router();

router.get('/', (req, res) => {
  res.json({
    flota: { total: 20, en_ruta: 8, en_base: 5, en_taller: 4, disponible: 3 },
    combustible: { critico: 2, sospechoso: 3, normal: 15 },
    sucursales: 3,
    escalable: "200 vehiculos"
  });
});

module.exports = router;
