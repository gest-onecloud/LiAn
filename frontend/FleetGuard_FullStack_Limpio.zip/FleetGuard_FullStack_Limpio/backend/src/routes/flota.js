const express = require('express');
const router = express.Router();

// Mock temporal - luego se conecta a BD real (PostgreSQL/Supabase o SQLite)
const flotaMock = [
  { placa: "FLT-101", marca: "Scania", modelo: "R-450", estado: "En Ruta", odometro: 45230, gps_id: "TELCEL-9001", sucursal: "SUC-CDMX-01" },
  { placa: "FLT-102", marca: "Mercedes", modelo: "Sprinter", estado: "En Base", odometro: 32100, gps_id: "TELCEL-9002", sucursal: "SUC-CDMX-01" },
  { placa: "FLT-103", marca: "Volvo", modelo: "FH-540", estado: "En Taller", odometro: 78100, gps_id: "TELCEL-9003", sucursal: "SUC-PUE-01" }
];

// GET /api/flota - Todas con filtro opcional ?estado=En Ruta&sucursal=SUC-CDMX-01
router.get('/', (req, res) => {
  let data = flotaMock;
  if (req.query.estado) data = data.filter(v => v.estado === req.query.estado);
  if (req.query.sucursal) data = data.filter(v => v.sucursal === req.query.sucursal);
  res.json(data);
});

router.get('/:placa', (req, res) => {
  const veh = flotaMock.find(v => v.placa === req.params.placa);
  if (!veh) return res.status(404).json({ error: "No encontrado" });
  res.json(veh);
});

module.exports = router;
