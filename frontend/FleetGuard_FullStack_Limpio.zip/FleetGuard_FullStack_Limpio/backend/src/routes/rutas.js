const express = require('express');
const router = express.Router();

router.get('/', (req, res) => {
  res.json([
    { nro: "VIAJE-1001", placa: "FLT-101", estado_consumo: "NORMAL", rendimiento: 7.1 },
    { nro: "VIAJE-1002", placa: "FLT-104", estado_consumo: "CRITICO", rendimiento: 4.3 }
  ]);
});

module.exports = router;
