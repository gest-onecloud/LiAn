// FleetGuard Backend - API REST Escalable
const express = require('express');
const cors = require('cors');
const path = require('path');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 10000;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, '../../frontend')));

// Routes
app.use('/api/flota', require('./routes/flota'));
app.use('/api/sucursales', require('./routes/sucursales'));
app.use('/api/rutas', require('./routes/rutas'));
app.use('/api/stats', require('./routes/stats'));

// Health check
app.get('/api/health', (req, res) => {
  res.json({ 
    status: 'OK', 
    version: '7.0.0',
    database: process.env.DATABASE_URL ? 'PostgreSQL/Supabase' : 'SQLite local',
    sucursales: 'Tabla preparada para futuro',
    flotilla: '200 vehiculos soportados'
  });
});

// Servir frontend para cualquier ruta no API
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, '../../frontend/index.html'));
});

app.listen(PORT, () => {
  console.log(`🚀 FleetGuard Backend en puerto ${PORT}`);
  console.log(`📁 Frontend: ../../frontend`);
  console.log(`🗄️  BD: ${process.env.DATABASE_URL ? 'PostgreSQL' : 'SQLite'}`);
  console.log(`🏢 Sucursales: Tabla lista para crecer`);
});
