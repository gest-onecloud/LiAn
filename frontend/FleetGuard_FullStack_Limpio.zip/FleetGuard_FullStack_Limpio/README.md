# FleetGuard FullStack Limpio - Frontend + Backend + BD Escalable

## Por qué esta estructura (lo que pediste)

**Frontend** - Lo que ve el cliente
- HTML/CSS/JS separados en `frontend/`
- Paleta V2: #07080A, #C6FF00, #00FFA3
- Filtros En Ruta/En Base/En Taller combinables

**Backend** - API que guarda y sirve datos
- Node + Express en `backend/src/server.js`
- Rutas: /api/flota, /api/sucursales, /api/rutas, /api/stats
- Crece sin romper: agregas una tabla y solo agregas una ruta nueva

**Base de Datos** - Que permite crecer
- PostgreSQL / Supabase (recomendado) o SQLite
- Schema en `database/schema.sql`
- Ya incluye tabla `sucursales` para futuro:
  - Matriz CDMX, Puebla, Querétaro
  - Cuando agregues sucursales, solo INSERT, no cambias código
  - Flota tiene `sucursal_id` para filtrar por sucursal

## Estructura limpia (para GitHub Desktop)

```
FleetGuard_FullStack_Limpio/
├── frontend/               # Static Site en Render
│   ├── index.html
│   ├── css/variables.css, layout.css, components.css
│   ├── js/config.js, db.js, modules/flota.js
│   └── assets/
├── backend/                # Web Service en Render
│   ├── src/server.js       # API principal
│   ├── src/routes/flota.js, sucursales.js
│   ├── package.json
│   └── Dockerfile
├── database/
│   ├── schema.sql          # Con tabla sucursales
│   └── migrations/
├── docker-compose.yml      # Para correr local: frontend+backend+db
└── README.md
```

## Cómo desplegar en Render (FullStack)

**Opción 1 - Separado (recomendado para empezar):**

1. **Backend como Web Service:**
   - New → Web Service → Conecta repo
   - Root Directory: backend
   - Build Command: npm install
   - Start Command: npm start
   - Env: PORT=10000

2. **Frontend como Static Site:**
   - New → Static Site → Mismo repo
   - Root Directory: frontend
   - Build Command: (vacío)
   - Publish Directory: ./

3. **Base de Datos:**
   - Opción A: Supabase (gratis) → importa database/schema.sql
   - Opción B: Render PostgreSQL → New → PostgreSQL

**Opción 2 - Todo junto con Docker (más pro):**

- New → Web Service → Usa Dockerfile del backend
- Render lee docker-compose y levanta backend+db

## Para desarrollo local:

```bash
docker-compose up
# Abre http://localhost:10000
# Frontend: http://localhost:10000/
# API: http://localhost:10000/api/flota
# Health: http://localhost:10000/api/health
```

## Próximos pasos:

1. Copia esta carpeta a C:\Users\jdcov\Documents\FleetGuard_Web (reemplaza todo)
2. GitHub Desktop → Commit: "Estructura FullStack limpia con sucursales"
3. Push
4. Render → El Web Service ya no fallará porque tiene Dockerfile y server.js
5. Prueba /api/health y /api/flota
6. Siguiente: Generamos frontend Capa 1 completo conectado a esta API
